import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame4 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame4 frame = new MainFrame4(3);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame4(int contador) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 423, 546);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 43, 235, 64);
		contentPane.add(panel);
		
		JTextPane txtpnElSistemaCuenta = new JTextPane();
		txtpnElSistemaCuenta.setText("El sistema se adapta a\r\ndiferentes SO sin necesidad\r\nde modificaciones");
		panel.add(txtpnElSistemaCuenta);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 149, 235, 64);
		contentPane.add(panel_1);
		
		JTextPane txtpnElSistemaMuestra = new JTextPane();
		txtpnElSistemaMuestra.setText("El software se puede instalar\r\nen una cantidad minima de pasos.");
		panel_1.add(txtpnElSistemaMuestra);
		
		JCheckBox chckbxAprueba = new JCheckBox("Aprueba");
		chckbxAprueba.setBounds(263, 83, 97, 23);
		contentPane.add(chckbxAprueba);
		
		JCheckBox checkBox = new JCheckBox("Aprueba");
		checkBox.setBounds(263, 190, 97, 23);
		contentPane.add(checkBox);
		
		JButton btnSiguiente = new JButton("Siguiente");
		btnSiguiente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int cont = contador;
				if(chckbxAprueba.isSelected())
					cont++;
				if(checkBox.isSelected())
					cont++;
				setVisible(false);
				FinalFrame ff = new FinalFrame(cont);
				ff.setVisible(true);
			}
		});
		btnSiguiente.setBounds(259, 473, 89, 23);
		contentPane.add(btnSiguiente);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(1);
			}
		});
		btnSalir.setBounds(78, 473, 89, 23);
		contentPane.add(btnSalir);
	}
}
