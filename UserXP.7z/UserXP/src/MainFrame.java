import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 423, 546);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 43, 235, 64);
		contentPane.add(panel);
		
		JTextPane txtpnElSistemaCuenta = new JTextPane();
		txtpnElSistemaCuenta.setText("El sistema cuenta con control de acceso \r\nvalidados por usuario y contrase\u00F1a");
		panel.add(txtpnElSistemaCuenta);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 149, 235, 64);
		contentPane.add(panel_1);
		
		JTextPane txtpnElSistemaMuestra = new JTextPane();
		txtpnElSistemaMuestra.setText("El sistema muestra los resultados exactos\r\nal relizar cualquiera de los procedimientos\r\n");
		panel_1.add(txtpnElSistemaMuestra);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 257, 235, 64);
		contentPane.add(panel_2);
		
		JTextPane txtpnElSistemaEs = new JTextPane();
		txtpnElSistemaEs.setText("El sistema es eficiente al ejecutar\r\ny no hace mas lentos a otros procesos.\r\n\r\n");
		panel_2.add(txtpnElSistemaEs);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(10, 365, 235, 64);
		contentPane.add(panel_3);
		
		JTextPane txtpnElTiempoDe = new JTextPane();
		txtpnElTiempoDe.setText("El tiempo de respuesta es bueno\r\ny la demora del procesamiento \r\nes aceptable.");
		panel_3.add(txtpnElTiempoDe);
		
		JCheckBox chckbxAprueba = new JCheckBox("Aprueba");
		chckbxAprueba.setBounds(263, 83, 97, 23);
		contentPane.add(chckbxAprueba);
		
		JCheckBox checkBox = new JCheckBox("Aprueba");
		checkBox.setBounds(263, 190, 97, 23);
		contentPane.add(checkBox);
		
		JCheckBox checkBox_1 = new JCheckBox("Aprueba");
		checkBox_1.setBounds(263, 295, 97, 23);
		contentPane.add(checkBox_1);
		
		JCheckBox checkBox_2 = new JCheckBox("Aprueba");
		checkBox_2.setBounds(263, 405, 97, 23);
		contentPane.add(checkBox_2);
		JButton btnSiguiente = new JButton("Siguiente");
		btnSiguiente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int contador = 0;
				if(chckbxAprueba.isSelected())
					contador++;
				if(checkBox.isSelected())
					contador++;
				if(checkBox_1.isSelected())
					contador++;
				if(checkBox_2.isSelected())
					contador++;
				setVisible(false);
				MainFrame2 mf2 = new MainFrame2(contador);
				mf2.setVisible(true);
			}
		});
		btnSiguiente.setBounds(259, 473, 89, 23);
		contentPane.add(btnSiguiente);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(1);
			}
		});
		btnSalir.setBounds(78, 473, 89, 23);
		contentPane.add(btnSalir);
	}
}
